<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<a href="<?php echo home_url(); ?>/search"> < Back to search</a>

<div class="container-fluid class-results-container">
  <div class="row">
    <?php $loop = new WP_Query(array( 'post_type' => 'class', 'posts_per_page' => -1 )); ?>
    <?php while ($loop->have_posts()) : $loop->the_post(); ?>
      <div class="col-xs-12 result-block" style="background-image: url('<?php the_field('hero_image'); ?>')">
        <div class="layer">
          <div class="block-content">
            <h4><?php the_title(); ?></h4>
            <?php the_field('class_time'); ?>
          </div>
        </div>
      </div>
    <?php endwhile; wp_reset_query(); ?>
  </div>
</div>


<?php endwhile; endif; ?>
