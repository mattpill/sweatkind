<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="back-to-button">
  <a href="<?php echo home_url(); ?>/welcome"> < Back to search</a>
</div>

<div class="container-fluid class-results-container">
  <div class="row">
    <?php $loop = new WP_Query(array( 'post_type' => 'class', 'category_name' => 'crossfit', 'posts_per_page' => -1 ));
    $term = get_field('crossfit');
    ?>
    <?php while ($loop->have_posts()) : $loop->the_post(); ?>
      <div class="col-xs-12 text-center col-md-4">
        <div class="result-block" style="background-image: url('<?php the_field('hero_image'); ?>')">
          <a href="<?php the_permalink(); ?>">
            <div class="layer">
              <div class="block-content">
                <h4><?php the_title(); ?></h4>
                <?php $format = "g a"; ?>
                <?php $class_time = strtotime(get_field('class_time')); ?>
                <?php echo date_i18n($format, $class_time); ?> |

                <?php $selected = get_field('class_day');
                  if (in_array('Monday', $selected)) : ?>
             	    Mon,
                <?php endif; if (in_array('Tuesday', $selected)) : ?>
                  Tue,
                <?php endif; if (in_array('Wednesday', $selected)) : ?>
                  Wed,
                <?php endif; if (in_array('Thursday', $selected)) : ?>
                  Thu,
                <?php endif; if (in_array('Friday', $selected)) : ?>
                  Fri,
                <?php endif; if (in_array('Saturday', $selected)) : ?>
                  Sat,
                <?php endif; if (in_array('Sunday', $selected)) : ?>
                  Sun
                <?php endif; ?>

                <?php

                // vars
                $field = get_field_object('class_day');
                $days = $field['value'];


                // check
                if( $days ): ?>
                  <?php $last = count($days); ?>
                  <?php $i = 1; ?>
                	<?php foreach( $days as $day ): ?>
                		<?php echo $field['choices'][ $day ]; ?>
                    <?php if ($i != $last) {
                        echo ',';
                     } ?>
                    <?php $i++ ?>
                	<?php endforeach; ?>
                <?php endif; ?>
                <br>
                <?php the_field('duration'); ?> mins
              </div>
            </div>
            </a>
          </div>
        <div class="results-buttons col-xs-12">
          <div class="row">
            <div class="price-button col-xs-4">
              £<?php the_field('cost'); ?>
            </div>
            <div class="info-button col-xs-4">
              <a href="<?php the_permalink(); ?>"><span>Info</span></a>
            </div>
            <div class="book-button col-xs-4">
              <a href="<?php the_permalink(); ?>"><span>Book</span></a>
            </div>
          </div>
        </div>
      </div>
    <?php endwhile; wp_reset_query(); ?>
  </div>
</div>


<?php endwhile; endif; ?>
