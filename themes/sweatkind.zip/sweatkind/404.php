<?php get_header(); ?>

<?php _e('Sorry, but the page you were trying to view does not exist.', 'tofino'); ?>

<?php get_footer(); ?>
