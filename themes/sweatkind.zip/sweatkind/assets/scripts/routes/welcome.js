// We need jQuery
var $ = window.jQuery;

export default {
  init() {
    console.log('Welcome');
    $(".btn-classes").click(function() {
        $('html,body').animate({
            scrollTop: $(".pick-class-section").offset().top},
            'slow');
    });
  },
  loaded() {
    // Javascript to be fired on page once fully loaded
  }
};
