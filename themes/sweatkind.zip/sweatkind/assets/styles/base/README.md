
These are the base styles that make Tofino work.

You probably don't want to edit them.

### Important

For performance reasons `bootstrap.scss` has been edited commenting out components which are not usually required for our website builds. Remember to un-comment any additional components you need for your build e.g. Tables, Carousel etc.
