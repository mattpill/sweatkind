<div class="login-container" style="background-image: url(<?php echo bloginfo('template_url') ?>/assets/images/SweatKind_Homepage_Gradient.png)">
  <div class="login-section" style="background-image: url(<?php echo bloginfo('template_url') ?>/assets/images/SweatKind_Homepage_Model-Skipping.png)">
    <div class="row">
      <div class="col-xs-12 login-content">
        <img src="<?php echo bloginfo('template_url') ?>/assets/images/SweatKind_Logo.png" alt="" />
        <a class="login" href="#">Log in</a>
        <button type="button" name="button">Sign Up</button>
        <a class="tandc" href="#">Terms &amp; Conditions</a>
      </div>
    </div>
  </div>
</div>
